/*!
 * Atomi Ajax Player - Media Player Interface
 * Copyright (c) Atomi Systems, Inc. All rights reserved.
 * http://atomisystems.com
 *
 */
MediaPlayer.SpanString=function(a){var c=Math.floor(a/3600);var b=Math.floor(a%3600/60);var d=Math.round(a%60*10)/10;var e=c+":"+b+":"+d;return e};MediaPlayer.Delegate=function(a,b){return function(){return b.apply(a,arguments)}};MediaPlayer.MediaEnded=function(){if(this.ctrlId===undefined){return}if(this.configs.repeat=="true"){this.player.Position=MediaPlayer.SpanString(0);this.player.play();return}var a=Prez.GetMediaUI(this.ctrlId);if(a&&a._OnPlayerEnded){a._OnPlayerEnded()}};MediaPlayer.PlayerReady=function(a,e,d){Log("Player Ready: "+e.ctrlId);var c=d.findName("VideoWindow");c.BufferingTime=MediaPlayer.SpanString(e.configs.bufferlength);c.AutoPlay=false;if(e.configs.file){c.Source=e.configs.file}var f={"true":"UniformToFill","false":"Uniform",fit:"Fill",none:"None"};c.Stretch=f[e.configs.overstretch];c.Width=d.getHost().content.actualWidth;c.Height=d.getHost().content.actualHeight;if(!e.mediaEndToken){e.mediaEndToken=c.AddEventListener("MediaEnded",MediaPlayer.Delegate(e,MediaPlayer.MediaEnded))}e.player=c;var b=Prez.GetMediaUI(e.ctrlId);if(b&&b._OnPlayerReady){b._OnPlayerReady()}};MediaPlayer.PlayerResize=function(c,a){var b=c.findName("VideoWindow");b.Width=c.getHost().content.actualWidth;b.Height=c.getHost().content.actualHeight};MediaPlayer.CmdInterval=50;function MediaPlayer(b,d,c){this.ctrlId=c;this.playerId=c+"_player";this.playerReady=false;this.player=null;this.mediaEndToken=null;this.configs={width:1,height:1,overstretch:"fit",volume:Prez.GetVolume(true),bufferlength:1,repeat:"false"};$.extend(this.configs,b);if(this.configs.files){this.configs.files=this.configs.files.split(",")}else{this.configs.files=[]}var a="100%",e="100%";if(this.configs.mode=="audio"){a=e="1"}var f=document.getElementById(d);Silverlight.createObjectEx({source:"mediaplayer.xaml",parentElement:f,properties:{id:this.playerId,width:a,height:e,version:"2.0",maxFrameRate:"30",EnableGPUAcceleration:"true",alt:" ",inplaceInstallPrompt:true,isWindowless:"true",background:"#000"},events:{onLoad:MediaPlayer.PlayerReady,onError:null,onResize:MediaPlayer.PlayerResize},context:this})}MediaPlayer.prototype={constructor:MediaPlayer,SetVolume:function(a){$(this).stopTime("sendvol");if(this.player===undefined){Log("MediaPlayer::SetVolume: Embed fail | "+this.playerId);return}if(this.player){this.player.Volume=a/100}else{if(this.playerReady){$(this).oneTime(MediaPlayer.CmdInterval,"sendvol",function(){Log("MediaPlayer::SetVolume called in Timer |"+this.playerId);this.SetVolume(a)})}}},Play:function(d,c,b){if(isNaN(c)){c=undefined}$(this).stopTime("sendplay");if(this.player===undefined){Log("MediaPlayer::Play: Embed fail | "+this.playerId);return}var a=this.player?this.player.CurrentState:"Closed";if(a=="Stopped"||a=="Paused"||a=="Playing"){if(d){if(!isNaN(c)){this.player.Position=MediaPlayer.SpanString(c)}this.player.play()}else{this.player.pause();if(!isNaN(c)){this.player.Position=MediaPlayer.SpanString(c)}}Log("MediaPlayer::Play: "+d+", "+c+" | "+this.playerId)}else{if(this.playerReady){if(isNaN(c)){c=b||0}$(this).oneTime(MediaPlayer.CmdInterval,"sendplay",function(){Log("MediaPlayer::Play called in Timer | "+this.playerId);c+=MediaPlayer.CmdInterval/1000;this.Play(d,c,c)})}}},PlayItem:function(a){$(this).stopTime("playitem").stopTime("sendplay");if(a<0&&a>=this.configs.files.length){return}if(this.player===undefined){Log("MediaPlayer::PlayItem: Embed fail | "+this.playerId);return}var c=this.configs.files[a];if(this.player&&c!=this.player.Source){this.player.Source=c}var b=this.player?this.player.CurrentState:"Closed";if(b=="Stopped"||b=="Paused"||b=="Playing"){if(b!="Stopped"){this.player.stop()}Log("MediaPlayer::PlayItem: "+a+" | "+this.playerId);this.player.play()}else{if(this.playerReady){$(this).oneTime(MediaPlayer.CmdInterval,"playitem",function(){Log("MediaPlayer::PlayItem called in Timer | "+this.playerId);this.PlayItem(a)})}}},IsReady:function(){return this.playerReady},SetPlayerReady:function(a){this.playerReady=a},GetId:function(){return this.playerId},CleanUp:function(){$(this).stopTime();if(this.player){if(this.mediaEndToken){var b=this.mediaEndToken;this.mediaEndToken=null;if(typeof(this.player.RemoveEventListener)==="function"){try{this.player.RemoveEventListener("MediaEnded",b)}catch(a){}}}this.player.Source="";this.player=null}this.playerReady=false}};
/*!
 *
 *  Silverlight.js   			version 5.0.61118.0
 *
 *  This file is provided by Microsoft as a helper file for websites that
 *  incorporate Silverlight Objects. This file is provided under the Microsoft
 *  Public License available at
 *  http://code.msdn.microsoft.com/silverlightjs/Project/License.aspx.
 *  You may not use or distribute this file or the code in this file except as
 *  expressly permitted under that license.
 *
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *
 */
if(!window.Silverlight){window.Silverlight={}}Silverlight._silverlightCount=0;Silverlight.__onSilverlightInstalledCalled=false;Silverlight.fwlinkRoot="http://go2.microsoft.com/fwlink/?LinkID=";Silverlight.__installationEventFired=false;Silverlight.onGetSilverlight=null;Silverlight.onSilverlightInstalled=function(){window.location.reload(false)};Silverlight.isInstalled=function(k){if(k==undefined){k=null}var n=false;var a=null;try{var g=null;var m=false;if(window.ActiveXObject){try{g=new ActiveXObject("AgControl.AgControl");if(k===null){n=true}else{if(g.IsVersionSupported(k)){n=true}}g=null}catch(j){m=true}}else{m=true}if(m){var h=navigator.plugins["Silverlight Plug-In"];if(h){if(k===null){n=true}else{var b=h.description;if(b==="1.0.30226.2"){b="2.0.30226.2"}var c=b.split(".");while(c.length>3){c.pop()}while(c.length<4){c.push(0)}var d=k.split(".");while(d.length>4){d.pop()}var l;var f;var i=0;do{l=parseInt(d[i]);f=parseInt(c[i]);i++}while(i<d.length&&l===f);if(l<=f&&!isNaN(l)){n=true}}}}}catch(j){n=false}return n};Silverlight.WaitForInstallCompletion=function(){if(!Silverlight.isBrowserRestartRequired&&Silverlight.onSilverlightInstalled){try{navigator.plugins.refresh()}catch(a){}if(Silverlight.isInstalled(null)&&!Silverlight.__onSilverlightInstalledCalled){Silverlight.onSilverlightInstalled();Silverlight.__onSilverlightInstalledCalled=true}else{setTimeout(Silverlight.WaitForInstallCompletion,3000)}}};Silverlight.__startup=function(){navigator.plugins.refresh();Silverlight.isBrowserRestartRequired=Silverlight.isInstalled(null);if(!Silverlight.isBrowserRestartRequired){Silverlight.WaitForInstallCompletion();if(!Silverlight.__installationEventFired){Silverlight.onInstallRequired();Silverlight.__installationEventFired=true}}else{if(window.navigator.mimeTypes){var d=navigator.mimeTypes["application/x-silverlight-2"];var a=navigator.mimeTypes["application/x-silverlight-2-b2"];var b=navigator.mimeTypes["application/x-silverlight-2-b1"];var c=b;if(a){c=a}if(!d&&(b||a)){if(!Silverlight.__installationEventFired){Silverlight.onUpgradeRequired();Silverlight.__installationEventFired=true}}else{if(d&&c){if(d.enabledPlugin&&c.enabledPlugin){if(d.enabledPlugin.description!=c.enabledPlugin.description){if(!Silverlight.__installationEventFired){Silverlight.onRestartRequired();Silverlight.__installationEventFired=true}}}}}}}if(!Silverlight.disableAutoStartup){if(window.removeEventListener){window.removeEventListener("load",Silverlight.__startup,false)}else{window.detachEvent("onload",Silverlight.__startup)}}};if(!Silverlight.disableAutoStartup){if(window.addEventListener){window.addEventListener("load",Silverlight.__startup,false)}else{window.attachEvent("onload",Silverlight.__startup)}}Silverlight.createObject=function(a,j,c,h,l,f,g){var m=new Object();var d=h;var k=l;m.version=d.version;d.source=a;m.alt=d.alt;if(f){d.initParams=f}if(d.isWindowless&&!d.windowless){d.windowless=d.isWindowless}if(d.framerate&&!d.maxFramerate){d.maxFramerate=d.framerate}if(c&&!d.id){d.id=c}delete d.ignoreBrowserVer;
delete d.inplaceInstallPrompt;delete d.version;delete d.isWindowless;delete d.framerate;delete d.data;delete d.src;delete d.alt;if(Silverlight.isInstalled(m.version)){for(var b in k){if(k[b]){if(b=="onLoad"&&typeof k[b]=="function"&&k[b].length!=1){var i=k[b];k[b]=function(n){return i(document.getElementById(c),g,n)}}var e=Silverlight.__getHandlerName(k[b]);if(e!=null){d[b]=e;k[b]=null}else{throw"typeof events."+b+" must be 'function' or 'string'"}}}slPluginHTML=Silverlight.buildHTML(d)}else{slPluginHTML=Silverlight.buildPromptHTML(m)}if(j){j.innerHTML=slPluginHTML}else{return slPluginHTML}};Silverlight.buildHTML=function(c){var b=[];b.push('<object type="application/x-silverlight" data="data:application/x-silverlight,"');if(c.id!=null){b.push(' id="'+Silverlight.HtmlAttributeEncode(c.id)+'"')}if(c.width!=null){b.push(' width="'+c.width+'"')}if(c.height!=null){b.push(' height="'+c.height+'"')}b.push(" >");delete c.id;delete c.width;delete c.height;for(var a in c){if(c[a]){b.push('<param name="'+Silverlight.HtmlAttributeEncode(a)+'" value="'+Silverlight.HtmlAttributeEncode(c[a])+'" />')}}b.push("</object>");return b.join("")};Silverlight.createObjectEx=function(c){var b=c;var a=Silverlight.createObject(b.source,b.parentElement,b.id,b.properties,b.events,b.initParams,b.context);if(b.parentElement==null){return a}};Silverlight.buildPromptHTML=function(a){var d="";var c=Silverlight.fwlinkRoot;var b=a.version;if(a.alt){d=a.alt}else{if(!b){b=""}d="<a href='javascript:Silverlight.getSilverlight(\"{1}\");' style='text-decoration: none;'><img src='{2}' alt='Get Microsoft Silverlight' style='border-style: none'/></a>";d=d.replace("{1}",b);d=d.replace("{2}",c+"161376")}return d};Silverlight.getSilverlight=function(c){if(Silverlight.onGetSilverlight){Silverlight.onGetSilverlight()}var a="";var e=String(c).split(".");if(e.length>1){var d=parseInt(e[0]);if(isNaN(d)||d<2){a="1.0"}else{a=e[0]+"."+e[1]}}var b="";if(a.match(/^\d+\056\d+$/)){b="&v="+a}Silverlight.followFWLink("149156"+b)};Silverlight.followFWLink=function(a){top.location=Silverlight.fwlinkRoot+String(a)};Silverlight.HtmlAttributeEncode=function(b){var e;var d="";if(b==null){return null}for(var a=0;a<b.length;a++){e=b.charCodeAt(a);if(((e>96)&&(e<123))||((e>64)&&(e<91))||((e>43)&&(e<58)&&(e!=47))||(e==95)){d=d+String.fromCharCode(e)}else{d=d+"&#"+e+";"}}return d};Silverlight.default_error_handler=function(b,a){var c;var e=a.ErrorType;c=a.ErrorCode;var d="\nSilverlight error message     \n";d+="ErrorCode: "+c+"\n";d+="ErrorType: "+e+"       \n";d+="Message: "+a.ErrorMessage+"     \n";if(e=="ParserError"){d+="XamlFile: "+a.xamlFile+"     \n";d+="Line: "+a.lineNumber+"     \n";d+="Position: "+a.charPosition+"     \n"}else{if(e=="RuntimeError"){if(a.lineNumber!=0){d+="Line: "+a.lineNumber+"     \n";d+="Position: "+a.charPosition+"     \n"}d+="MethodName: "+a.methodName+"     \n"}}alert(d)};Silverlight.__cleanup=function(){for(var a=Silverlight._silverlightCount-1;a>=0;a--){window["__slEvent"+a]=null}Silverlight._silverlightCount=0;if(window.removeEventListener){window.removeEventListener("unload",Silverlight.__cleanup,false)}else{window.detachEvent("onunload",Silverlight.__cleanup)}};Silverlight.__getHandlerName=function(b){var a="";if(typeof b=="string"){a=b}else{if(typeof b=="function"){if(Silverlight._silverlightCount==0){if(window.addEventListener){window.addEventListener("unload",Silverlight.__cleanup,false)}else{window.attachEvent("onunload",Silverlight.__cleanup)}}var c=Silverlight._silverlightCount++;a="__slEvent"+c;window[a]=b}else{a=null}}return a};Silverlight.onRequiredVersionAvailable=function(){};Silverlight.onRestartRequired=function(){};Silverlight.onUpgradeRequired=function(){};Silverlight.onInstallRequired=function(){};Silverlight.IsVersionAvailableOnError=function(b,a){var d=false;try{if(a.ErrorCode==8001&&!Silverlight.__installationEventFired){Silverlight.onUpgradeRequired();Silverlight.__installationEventFired=true}else{if(a.ErrorCode==8002&&!Silverlight.__installationEventFired){Silverlight.onRestartRequired();Silverlight.__installationEventFired=true}else{if(a.ErrorCode==5014||a.ErrorCode==2106){if(Silverlight.__verifySilverlight2UpgradeSuccess(a.getHost())){d=true}}else{d=true}}}}catch(c){}return d};Silverlight.IsVersionAvailableOnLoad=function(a){var c=false;try{if(Silverlight.__verifySilverlight2UpgradeSuccess(a.getHost())){c=true}}catch(b){}return c};Silverlight.__verifySilverlight2UpgradeSuccess=function(b){var f=false;var a="4.0.50401";var d=null;try{if(b.IsVersionSupported(a+".99")){d=Silverlight.onRequiredVersionAvailable;f=true}else{if(b.IsVersionSupported(a+".0")){d=Silverlight.onRestartRequired}else{d=Silverlight.onUpgradeRequired}}if(d&&!Silverlight.__installationEventFired){d();Silverlight.__installationEventFired=true}}catch(c){}return f};
// SIG // Begin signature block
// SIG // MIIauwYJKoZIhvcNAQcCoIIarDCCGqgCAQExCzAJBgUr
// SIG // DgMCGgUAMGcGCisGAQQBgjcCAQSgWTBXMDIGCisGAQQB
// SIG // gjcCAR4wJAIBAQQQEODJBs441BGiowAQS9NQkAIBAAIB
// SIG // AAIBAAIBAAIBADAhMAkGBSsOAwIaBQAEFKLOxVGkgmC+
// SIG // EddX2vzYD/pQ9XLaoIIVgjCCBMMwggOroAMCAQICEzMA
// SIG // AAAz5SeGow5KKoAAAAAAADMwDQYJKoZIhvcNAQEFBQAw
// SIG // dzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
// SIG // b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
// SIG // Y3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWlj
// SIG // cm9zb2Z0IFRpbWUtU3RhbXAgUENBMB4XDTEzMDMyNzIw
// SIG // MDgyM1oXDTE0MDYyNzIwMDgyM1owgbMxCzAJBgNVBAYT
// SIG // AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
// SIG // EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
// SIG // cG9yYXRpb24xDTALBgNVBAsTBE1PUFIxJzAlBgNVBAsT
// SIG // Hm5DaXBoZXIgRFNFIEVTTjpGNTI4LTM3NzctOEE3NjEl
// SIG // MCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
// SIG // dmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
// SIG // ggEBAMreyhkPH5ZWgl/YQjLUCG22ncDC7Xw4q1gzrWuB
// SIG // ULiIIQpdr5ctkFrHwy6yTNRjdFj938WJVNALzP2chBF5
// SIG // rKMhIm0z4K7eJUBFkk4NYwgrizfdTwdq3CrPEFqPV12d
// SIG // PfoXYwLGcD67Iu1bsfcyuuRxvHn/+MvpVz90e+byfXxX
// SIG // WC+s0g6o2YjZQB86IkHiCSYCoMzlJc6MZ4PfRviFTcPa
// SIG // Zh7Hc347tHYXpqWgoHRVqOVgGEFiOMdlRqsEFmZW6vmm
// SIG // y0LPXVRkL4H4zzgADxBr4YMujT5I7ElWSuyaafTLDxD7
// SIG // BzRKYmwBjW7HIITKXNFjmR6OXewPpRZIqmveIS8CAwEA
// SIG // AaOCAQkwggEFMB0GA1UdDgQWBBQAWBs+7cXxBpO+MT02
// SIG // tKwLXTLwgTAfBgNVHSMEGDAWgBQjNPjZUkZwCu1A+3b7
// SIG // syuwwzWzDzBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
// SIG // Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0
// SIG // cy9NaWNyb3NvZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsG
// SIG // AQUFBwEBBEwwSjBIBggrBgEFBQcwAoY8aHR0cDovL3d3
// SIG // dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3Nv
// SIG // ZnRUaW1lU3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsG
// SIG // AQUFBwMIMA0GCSqGSIb3DQEBBQUAA4IBAQAC/+OMA+rv
// SIG // fji5uXyfO1KDpPojONQDuGpZtergb4gD9G9RapU6dYXo
// SIG // HNwHxU6dG6jOJEcUJE81d7GcvCd7j11P/AaLl5f5KZv3
// SIG // QB1SgY52SAN+8psXt67ZWyKRYzsyXzX7xpE8zO8OmYA+
// SIG // BpE4E3oMTL4z27/trUHGfBskfBPcCvxLiiAFHQmJkTkH
// SIG // TiFO3mx8cLur8SCO+Jh4YNyLlM9lvpaQD6CchO1ctXxB
// SIG // oGEtvUNnZRoqgtSniln3MuOj58WNsiK7kijYsIxTj2hH
// SIG // R6HYAbDxYRXEF6Et4zpsT2+vPe7eKbBEy8OSZ7oAzg+O
// SIG // Ee/RAoIxSZSYnVFIeK0d1kC2MIIE7DCCA9SgAwIBAgIT
// SIG // MwAAALARrwqL0Duf3QABAAAAsDANBgkqhkiG9w0BAQUF
// SIG // ADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
// SIG // Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
// SIG // TWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
// SIG // aWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQTAeFw0xMzAx
// SIG // MjQyMjMzMzlaFw0xNDA0MjQyMjMzMzlaMIGDMQswCQYD
// SIG // VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
// SIG // A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
// SIG // IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYD
// SIG // VQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0G
// SIG // CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDor1yiIA34
// SIG // KHy8BXt/re7rdqwoUz8620B9s44z5lc/pVEVNFSlz7SL
// SIG // qT+oN+EtUO01Fk7vTXrbE3aIsCzwWVyp6+HXKXXkG4Un
// SIG // m/P4LZ5BNisLQPu+O7q5XHWTFlJLyjPFN7Dz636o9UEV
// SIG // XAhlHSE38Cy6IgsQsRCddyKFhHxPuRuQsPWj/ov0DJpO
// SIG // oPXJCiHiquMBNkf9L4JqgQP1qTXclFed+0vUDoLbOI8S
// SIG // /uPWenSIZOFixCUuKq6dGB8OHrbCryS0DlC83hyTXEmm
// SIG // ebW22875cHsoAYS4KinPv6kFBeHgD3FN/a1cI4Mp68fF
// SIG // SsjoJ4TTfsZDC5UABbFPZXHFAgMBAAGjggFgMIIBXDAT
// SIG // BgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQUWXGm
// SIG // WjNN2pgHgP+EHr6H+XIyQfIwUQYDVR0RBEowSKRGMEQx
// SIG // DTALBgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNTk1KzRm
// SIG // YWYwYjcxLWFkMzctNGFhMy1hNjcxLTc2YmMwNTIzNDRh
// SIG // ZDAfBgNVHSMEGDAWgBTLEejK0rQWWAHJNy4zFha5TJoK
// SIG // HzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1p
// SIG // Y3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWND
// SIG // b2RTaWdQQ0FfMDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUH
// SIG // AQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
// SIG // Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BD
// SIG // QV8wOC0zMS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOC
// SIG // AQEAMdduKhJXM4HVncbr+TrURE0Inu5e32pbt3nPApy8
// SIG // dmiekKGcC8N/oozxTbqVOfsN4OGb9F0kDxuNiBU6fNut
// SIG // zrPJbLo5LEV9JBFUJjANDf9H6gMH5eRmXSx7nR2pEPoc
// SIG // sHTyT2lrnqkkhNrtlqDfc6TvahqsS2Ke8XzAFH9IzU2y
// SIG // RPnwPJNtQtjofOYXoJtoaAko+QKX7xEDumdSrcHps3Om
// SIG // 0mPNSuI+5PNO/f+h4LsCEztdIN5VP6OukEAxOHUoXgSp
// SIG // Rm3m9Xp5QL0fzehF1a7iXT71dcfmZmNgzNWahIeNJDD3
// SIG // 7zTQYx2xQmdKDku/Og7vtpU6pzjkJZIIpohmgjCCBbww
// SIG // ggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEF
// SIG // BQAwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcGCgmS
// SIG // JomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWlj
// SIG // cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
// SIG // MB4XDTEwMDgzMTIyMTkzMloXDTIwMDgzMTIyMjkzMlow
// SIG // eTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
// SIG // b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
// SIG // Y3Jvc29mdCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWlj
// SIG // cm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EwggEiMA0GCSqG
// SIG // SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2a
// SIG // YCAgQpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/
// SIG // 3sJCTiPVcgDbNVcKicquIEn08GisTUuNpb15S3GbRwfa
// SIG // /SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
// SIG // cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJp
// SIG // L9oZC/6SdCnidi9U3RQwWfjSjWL9y8lfRjFQuScT5EAw
// SIG // z3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vXT2Pn
// SIG // 0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdc
// SIG // pReejcsRj1Y8wawJXwPTAgMBAAGjggFeMIIBWjAPBgNV
// SIG // HRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK0rQWWAHJ
// SIG // Ny4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGC
// SIG // NxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQU/dExTtMm
// SIG // ipXhmGA7qDFvpjy82C0wGQYJKwYBBAGCNxQCBAweCgBT
// SIG // AHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8
// SIG // KuEKU5VZ5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDov
// SIG // L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
// SIG // dHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUF
// SIG // BwEBBEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5t
// SIG // aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRS
// SIG // b290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
// SIG // Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svp
// SIG // LTGjI8x8UJiAIV2sPS9MuqKoVpzjcLu4tPh5tUly9z7q
// SIG // QX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOlVuC4
// SIG // iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y
// SIG // 4k74jKHK6BOlkU7IG9KPcpUqcW2bGvgc8FPWZ8wi/1wd
// SIG // zaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/TartSCMm78
// SIG // pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q7
// SIG // 0eFW6NB4lhhcyTUWX92THUmOLb6tNEQc7hAVGgBd3TVb
// SIG // Ic6YxwnuhQ6MT20OE049fClInHLR82zKwexwo1eSV32U
// SIG // jaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKN
// SIG // MxZlHg6K3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsT
// SIG // J0Ct5PnhqX9GuwdgR2VgQE6wQuxO7bN2edgKNAltHIAx
// SIG // H+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJ
// SIG // jdibIa4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmI
// SIG // z2qoRzEvmtzjcT3XAH5iR9HOiMm4GPoOco3Boz2vAkBq
// SIG // /2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
// SIG // NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
// SIG // iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWlj
// SIG // cm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBD
// SIG // ZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1
// SIG // MzA5WhcNMjEwNDAzMTMwMzA5WjB3MQswCQYDVQQGEwJV
// SIG // UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
// SIG // UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
// SIG // cmF0aW9uMSEwHwYDVQQDExhNaWNyb3NvZnQgVGltZS1T
// SIG // dGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7d
// SIG // GE4kD+7Rp9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr
// SIG // 6Hu97IkHD/cOBJjwicwfyzMkh53y9GccLPx754gd6udO
// SIG // o6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDl
// SIG // KEYuJ6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd+
// SIG // +NIT8wi3U21StEWQn0gASkdmEScpZqiX5NMGgUqi+YSn
// SIG // EUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
// SIG // eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiAL
// SIG // AgMBAAGjggGrMIIBpzAPBgNVHRMBAf8EBTADAQH/MB0G
// SIG // A1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzALBgNV
// SIG // HQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1Ud
// SIG // IwSBkDCBjYAUDqyCYEBWJ5flJRP8KuEKU5VZ5KShY6Rh
// SIG // MF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAXBgoJkiaJ
// SIG // k/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jv
// SIG // c29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eYIQ
// SIG // ea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8ESTBHMEWgQ6BB
// SIG // hj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
// SIG // bC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmww
// SIG // VAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjhodHRw
// SIG // Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01p
// SIG // Y3Jvc29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggr
// SIG // BgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAgEAEJeKw1wD
// SIG // RDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
// SIG // YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB
// SIG // 7uK+jwoFyI1I4vBTFd1Pq5Lk541q1YDB5pTyBi+FA+mR
// SIG // KiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxnLcVR
// SIG // DupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPf
// SIG // wgphjvDXuBfrTot/xTUrXqO/67x9C0J71FNyIe4wyrt4
// SIG // ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW6J1wlGys
// SIG // OUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89D
// SIG // s+X57H2146SodDW4TsVxIxImdgs8UoxxWkZDFLyzs7BN
// SIG // Z8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD6Svpu/RIzCzU
// SIG // 2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LB
// SIG // J1S2sWo9iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJ
// SIG // Zr2dHYcSZAI9La9Zj7jkIeW1sMpjtHhUBdRBLlCslLCl
// SIG // eKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/J
// SIG // mu5J4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6
// SIG // L54/LlUWa8kTo/0xggSlMIIEoQIBATCBkDB5MQswCQYD
// SIG // VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
// SIG // A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
// SIG // IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQg
// SIG // Q29kZSBTaWduaW5nIFBDQQITMwAAALARrwqL0Duf3QAB
// SIG // AAAAsDAJBgUrDgMCGgUAoIG+MBkGCSqGSIb3DQEJAzEM
// SIG // BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
// SIG // BgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBQtQUkESeba
// SIG // 4HU/zdCACaOZLQlzDzBeBgorBgEEAYI3AgEMMVAwTqAm
// SIG // gCQATQBpAGMAcgBvAHMAbwBmAHQAIABMAGUAYQByAG4A
// SIG // aQBuAGehJIAiaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
// SIG // L2xlYXJuaW5nIDANBgkqhkiG9w0BAQEFAASCAQCCA4Fx
// SIG // JFES8/f8wA3Mw/MCT6YuW9HkIiaLdCkLBRi98cE2cCtA
// SIG // y/a7OK/S7uRhZfXwX4T/SjEvqHVkxWLXFRrrAppYCCNt
// SIG // MoHAlclveHaEesRX6O3iC21HbLW0IzuIfeluWgoCPEt2
// SIG // /psSRmy1HCtewizPNCqnFNvKQAB7ZkTFUDCN753m8d+H
// SIG // uTjPKKil9ajAqThZCsvmBCAomU9Xlk9R755xYbKBu8ls
// SIG // bZHQw+vt8Q1hJwmMUq32lM2oe2aTY6ypiWA2FuO5walF
// SIG // JZJWnMvtmSoo4PiyrusmH6hDwl5RqcRcGNQKE6a0AGi1
// SIG // UZLwYuOq6wh5mN+1xkHz4w/wXOY5oYICKDCCAiQGCSqG
// SIG // SIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYT
// SIG // AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
// SIG // EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
// SIG // cG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1l
// SIG // LVN0YW1wIFBDQQITMwAAADPlJ4ajDkoqgAAAAAAAMzAJ
// SIG // BgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3
// SIG // DQEHATAcBgkqhkiG9w0BCQUxDxcNMTMwNTE1MTYwODQ3
// SIG // WjAjBgkqhkiG9w0BCQQxFgQUr4qp0dj8jj9Oc5oTQ1f1
// SIG // 0mHLMnkwDQYJKoZIhvcNAQEFBQAEggEAqOHT2YXQnS73
// SIG // 52vWEGIAdDSXZ9WjdrHHK4dwFmMAGVRiCDxC9nKq4bi6
// SIG // GO1R2zCq6uFilwWuM5OJlZ3kRKX7Vp5Q6ludmO8Q/gRF
// SIG // Nq4dE2e+QfjW3wL8ATkNtB/5xzU+VgHp+rpJ9skTASAA
// SIG // COKcihS2l6gVizOeXeINEZ95giHZVsvrXyand/aECQ5J
// SIG // 2fnNVkNlqOuRtsSkbrnNb3dl304HFtfaw9yaWTvErn9/
// SIG // K/8cdCL/c/Jmq1651PSIhCwgGi6VRj+VHjMPTKYYDr43
// SIG // INyHlnpoLlL60/iA1Vzi4EagOMzDUwVGEAjqKdkzcnmJ
// SIG // lbgMRqMdRUYJKI3StwXnTQ==
// SIG // End signature block
